
#To removes all previous work
rm(list = ls(all = TRUE))
ls()

##########################################################################################################
#Loading the data

setwd("B:\\Machine Learning\\Mini Project\\Use Cases\\Default of Credit Card Clients Dataset")
data <- read.csv('UCI_Credit_Card.csv')
#View(data)
#summary(data)
#str(data)

##########################################################################################################
#Splitting dataset into training and test dataset with ration as 70:30

set.seed(12)
trainingSetIndex <- sample(seq_len(nrow(data)), size = floor(0.70 * nrow(data)))
trainingData <- data[trainingSetIndex,]
testData <- data[-trainingSetIndex,]
#View(trainingData)
#View(testData)

##########################################################################################################
#Applying decition tree algoritm using C50

library(C50)
model <- C5.0(trainingData[-25], as.factor(trainingData$default.payment.next.month))
#model
summary(model)
plot(model)

##########################################################################################################
#Applying model on test data

predicted_value <-predict(model,testData)
testData$prediction <- predicted_value
#View(testData)

##########################################################################################################
#Table for comparing prediction output vs actual output

Actual_Output <- testData$default.payment.next.month
Predicted_Output <- testData$prediction

library(gmodels)
CrossTable(Predicted_Output, Actual_Output, prop.chisq = FALSE, prop.c = FALSE, prop.r = FALSE, 
           dnn = c('Predicted Output', 'Actual Output'))

accuracy_table <- table(Predicted_Output, Actual_Output)
accuracy <- sum(diag(accuracy_table))/sum(accuracy_table)
print(paste("Model Accuracy is ", round(accuracy*100,2), "%"))

##########################################################################################################
