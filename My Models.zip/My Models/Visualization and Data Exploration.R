
#To removes all previous work
rm(list = ls(all = TRUE))
ls()

##########################################################################################################

#install.packages('readr')
#install.packages('caTools')
#install.packages('class')
#install.packages('caret')
#install.packages('ROCR')
#install.packages('pROC')
#install.packages('factoextra')
#install.packages('ggplot2')
#install.packages('ggthemes')
#install.packages('scales')
#install.packages('dplyr')
#install.packages('mice')
#install.packages('randomForest')
#install.packages('gtools')
#install.packages('corrplot')
#install.packages('Hmisc')
#install.packages('devtools')
#install.packages('PerformanceAnalytics')
#install.packages('FactoMineR')

library(ggplot2)
library(readr)
library(caTools)
library(class)
library(caret)
library(ROCR)
library(pROC)
library(factoextra)
library(ggthemes)
library(scales)
library(dplyr)
library(mice)
library(randomForest)
library(gtools)
library(corrplot)
library(Hmisc)
library(devtools)
library(PerformanceAnalytics)
library(FactoMineR)

#setwd("B:\\Machine Learning\\Mini Project\\Use Cases\\Default of Credit Card Clients data")
#data <- read.csv('UCI_Credit_Card.csv')
data <- read.csv(file.choose())
View(data)
summary(data)
colnames(data)
unique(data$EDUCATION)

#Lets do a pre processing of data, and before that lets have a look at the structure of the data. 
str(data)

#From the results we see that there are variables which has to be converted to factors
#(SEX,MARRIAGE,EDUCATION,PAY_0,PAY_2 TO PAY_6,DEFAULT. )
#Lets Start with dropping the ID, as we wont get any informations from them.
data = data[-1]
datafactor <-c(2,3,4,6:11,24)
data[,datafactor]<-lapply(data[,datafactor],factor)

#After the conversion, we have certain variables which are continious.
#Being continious data is prone is non-standardization.
#To make the data standardise, we use feature scaling to do the same.
#datascaled1 <- c(1,5,12:23)
#data[,datascaled1]<-lapply(data[,datascaled1],scale)

#Now, lets take a final look at how our data is structured. 
str(data)
#View(data)

plot(x = data$LIMIT_BAL, y = data$LIMIT_BAL, xlab = "LIMIT_BAL", ylab = "LIMIT_BAL")

#we can see from the output that our data is cleaned and processed the way we need to do. 
#Lets Visualize the given data to get the feel of the data. 
#Kindly note, we are not drawing any conclusion from the graphs below.
#It is just an overview of how the data is spread across the data. 
#The following plot compares the Gender with the defaulters.
#This is to get an idea of which gender is defaulting most. 
GDS<-ggplot(data,aes(data$default.payment.next.month,fill=SEX))
GDS+geom_bar(position="dodge")+ggtitle("Comparison of Sex Vs Defaulters")+xlab("Default - Yes / No")+ylab("Count of Persons")

#Education plays a major role in identifying which class of people are defaulting the most. With the graph below we can get an overview. 
DEdu<-ggplot(data,aes(data$default.payment.next.month,fill=EDUCATION))
DEdu+geom_bar(position="stack")+ggtitle("Comparison of Education Vs Defaulters")+xlab("Default - Yes / No")+ylab("Count of Persons")

par(mfrow = c(1,1))

#This is another level of visualization to check about the defaulters. 
Mar<-ggplot(data,aes(data$default.payment.next.month,fill=MARRIAGE))
Mar+geom_bar(position="dodge")+ggtitle("Comparison of Marriage Vs Defaulters")+xlab("Default - Yes / No")+ylab("Count of Persons")

g3 = ggplot(data,aes(data$default.payment.next.month, color = SEX))
g3 + geom_bar() + facet_wrap(~ MARRIAGE)+ggtitle("Comparison of Educatin Vs Sex Vs Defaulters")+xlab("Default - Yes / No")+ylab("Count of Persons")

ggplot(data, aes(x=data$MARRIAGE))+geom_bar()+facet_wrap(~data$default.payment.next.month)

ggplot(data,aes(x = data$AGE, y = data$SEX, fill=default.payment.next.month))+geom_bar()+ggtitle("Comparison of Gender Vs Age Vs Defaulters")+xlab("Gender")+ylab("Age")

