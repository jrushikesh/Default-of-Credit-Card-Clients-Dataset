
#install.packages("fpc")
#Packages used for Clustering and plotting
library(fpc)

#Dataset to be loaded
credit_card<-read.csv(file.choose())

#Analyzing the dataset for any preprocessing
View(credit_card)
str(credit_card)
dim(credit_card)
summary(credit_card)
sum(is.na(credit_card))

#We are considering SEX,EDUCATION,MARRIAGE,AGE and default.payment.next.month for clustering
credit_card[3:6]<-lapply(credit_card[3:6],as.numeric)
credit_card$default.payment.next.month<-as.numeric(credit_card$default.payment.next.month)

#CLustering on basis of defalult paymnet=1
credit_card<-subset(credit_card,default.payment.next.month==1)
credit_card<-credit_card[c(3,4,5,6,25)]

str(credit_card)
dim(credit_card)

set.seed(12)

#Applying kmeans initially 2 clusters
cluster<-kmeans(credit_card,2,nstart = 20)
cluster
cluster$cluster<-as.factor(cluster$cluster)

#Plotting the results
plot(credit_card,col=(cluster$cluster))
plotcluster(credit_card,cluster$cluster)

#Checking optimal number of clusters
elbow_graph <- function(credit_card, nc, seed=12345){
  eg <- (nrow(credit_card)-1)*sum(apply(credit_card,2,var))
  for (i in 2:nc){
    set.seed(seed)
    eg[i] <- sum(kmeans(credit_card, centers=i)$withinss)}
  plot(1:nc, eg, type="b", xlab="Number of Clusters",
       ylab="Within groups sum of squares")}

elbow_graph(credit_card, nc=10) 

#After 4 clusters the oberved difference within groups of sum of squares is not substanial. Hence
# we can say that optimal cluster to be used is 4. Performing kmeans with 4 clusters.

set.seed(12)
cluster<-kmeans(credit_card,4,nstart = 20)
cluster$cluster<-as.factor(cluster$cluster)

#Plotting the results after applying kmeans with optimal cluster
plot(credit_card,col=cluster$cluster)
plotcluster(credit_card,cluster$cluster)

#Analyzing the result of clustering algorithm
cluster
cluster$centers

aggregate(credit_card,by=list(cluster=cluster$cluster),mean)

#Interpreting the results
#cluster 1 and 2 indicates that MALE client with Education as University and 
# maritial status as married with age group in range approx to 43 to 54 make defalut payment

# cluster 3 and 4 indicates that MALE client with Education as graduate school and 
# maritial status as married with  age group in range approx to 26 to 35 make defalut payment