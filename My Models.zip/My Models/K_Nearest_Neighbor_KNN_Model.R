
#To removes all previous work
rm(list = ls(all = TRUE))
ls()

##########################################################################################################
#Loading the data

setwd("B:\\Machine Learning\\Mini Project\\Use Cases\\Default of Credit Card Clients Dataset")
data <- read.csv('UCI_Credit_Card.csv')
#View(data)
#summary(data)
#str(data)

##########################################################################################################
#Splitting dataset into training and test dataset with ration as 70:30

set.seed(12)
trainingSetIndex <- sample(seq_len(nrow(data)), size = floor(0.70 * nrow(data)))
trainingData <- data[trainingSetIndex,]
testData <- data[-trainingSetIndex,]
#View(trainingData)
#View(testData)

##########################################################################################################
