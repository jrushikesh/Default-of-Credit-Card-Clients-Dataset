
#To removes all previous work
rm(list = ls(all = TRUE))
ls()

##########################################################################################################
#Loading the data

setwd("B:\\Machine Learning\\Mini Project\\Use Cases\\Default of Credit Card Clients Dataset")
data <- read.csv('UCI_Credit_Card.csv')
#View(data)
#summary(data)
#str(data)

##########################################################################################################
#Splitting dataset into training and test dataset with ration as 70:30

set.seed(123)
trainingSetIndex <- sample(seq_len(nrow(data)), size = floor(0.70 * nrow(data)))
trainingData <- data[trainingSetIndex,]
testData <- data[-trainingSetIndex,]
#View(trainingData)
#View(testData)

##########################################################################################################
#Logistic regression model

model <- glm(default.payment.next.month ~ LIMIT_BAL + SEX + EDUCATION + MARRIAGE + AGE + PAY_0 + PAY_2 + 
               PAY_3 + PAY_4 + PAY_5 + PAY_6 + BILL_AMT1 + BILL_AMT2 + BILL_AMT3 + BILL_AMT4 + BILL_AMT5 + 
               BILL_AMT6 + PAY_AMT1 + PAY_AMT2 + PAY_AMT3 + PAY_AMT4 + PAY_AMT5 + PAY_AMT6, data = trainingData, 
             family=binomial)
summary(model)

##########################################################################################################
#Revised model after removing insignificant variables

rev_model <- glm(default.payment.next.month ~ LIMIT_BAL + SEX + EDUCATION + MARRIAGE + AGE + PAY_0 + PAY_2 + 
               PAY_3 +  BILL_AMT1 + PAY_AMT1 + PAY_AMT2 , data = trainingData, 
               family = binomial)
summary(rev_model)

##########################################################################################################
#Adding column to test dataset for prediction probability

#Getting predicted probability of default variable for the test dataset
probabilityForTestData <- predict(rev_model, testData, type = "response")

#Adding new column to test dataset for prediced values
testData$predicted_value <- probabilityForTestData

#View(testData)

##########################################################################################################
#Map the probabilities for above prediction

#First insert all the values as 1 in new column
testData$prediction <- rep(1, nrow(testData))

#Update the value to 0 if the probability is smaller than 0.5
testData$prediction[testData$predicted_value < 0.5] <- 0

#table(testData$prediction)

##########################################################################################################
#Table for comparing prediction output vs actual output

Actual_Output <- testData$default.payment.next.month
Predicted_Output <- testData$prediction

library(gmodels)
CrossTable(Predicted_Output, Actual_Output, prop.chisq = FALSE, prop.c = FALSE, prop.r = FALSE, 
           dnn = c('Predicted Output', 'Actual Output'))

accuracy_table <- table(Predicted_Output, Actual_Output)
accuracy <- sum(diag(accuracy_table))/sum(accuracy_table)
print(paste("Model Accuracy is ", round(accuracy*100,2), "%"))

library(pROC)
rocCurve <- roc(default.payment.next.month ~ predicted_value, data = testData)
plot(rocCurve)

##########################################################################################################
