library(shiny)
shinyUI(fluidPage(
  titlePanel(h2("ML Project Group 1", align = "center")),
  sidebarLayout(
    sidebarPanel(
      fileInput("file", "Please upload file"),
      br(),
      selectInput("option", "Please select the desired option", 
                  choices = c("Summary", "View Data", "Logistic Regression", "Decision Tree", #"Support Vector Machine (SVM)", 
                              "Random Forest"))
      #downloadButton('downloadPlot', 'Download')
    ),
    mainPanel(
      h4(uiOutput("selectedOptionOutput"))
    )
  )
))