library(shiny)
shinyUI(fluidPage(
  titlePanel(h2("ML Project Group 1", align = "center")),
  sidebarLayout(
    sidebarPanel(
      fileInput("file", "Please upload file"),
      br(),
      selectInput("option", "Please select the desired option", choices = c("Summary", "Logistic Regression", "Decision Tree", "Random Forest"))
      #submitButton("Upload")
    ),
    mainPanel(
      h4(uiOutput("selectedOptionOutput"))
    )
  )
))